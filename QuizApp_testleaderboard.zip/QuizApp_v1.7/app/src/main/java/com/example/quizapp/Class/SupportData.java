package com.example.quizapp.Class;

import android.widget.Toast;

import com.mongodb.client.MongoClient;

public class SupportData {

    public MongoClient createConnection() {
        MongoClientURI uri = new MongoClientURI("mongodb+srv://terriertrivia:2021@cluster0-hvwrm.mongodb.net/LeaderBoard?retryWrites=true&w=majority");
        MongoClient mongoClient = new MongoClient(uri);
        return mongoClient;
    }

    public String createPlayer(String name, int score) {
        return String.format("{\"name\": \"%s\", "+ "\"score\": \"%d\", ", name, score);
    }
}
