package com.example.quizapp.Class;

public class User
{
    public String name;
    public int score;

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public int getScore()
    {
            return phone_nubmer;
    }

    public void setScore(int score)
    {
            this.score = score;
    }

}
